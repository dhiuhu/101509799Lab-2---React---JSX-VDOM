import React from 'react';

function MyComponent(props) {
	const handleClick = () => alert('Hello, React!');
console.log(props)
 return (
 <div>
  <h1>Hello, React!</h1>
  <button onClick={handleClick}>Click Me</button>
 </div>
);
}
export default MyComponent;
