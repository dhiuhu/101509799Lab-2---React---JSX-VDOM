import React from 'react';
import Todo from './components/Todo';


function App() {
  return (
    <div className="App">
      <Todo />
    </div>
         );
		}

export default App;
